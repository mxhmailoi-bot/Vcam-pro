import './globals.css';
export const metadata = { title: 'VCAM Pro', description: 'VCAM Pro social account management dashboard' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="vi"><body>{children}</body></html>;
}