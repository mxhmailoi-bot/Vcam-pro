const stats = [
  ['Khách hàng', '128', '+12 tháng này'],
  ['Đơn đang xử lý', '37', '8 cần chú ý'],
  ['Doanh thu', '₫48.6M', '+18.4%'],
  ['Tài khoản', '214', '98% hoạt động']
];

const orders = [
  ['#VC-1048', 'Nguyễn Minh', 'Hỗ trợ tài khoản', 'Đang xử lý', '₫650.000'],
  ['#VC-1047', 'Trần Anh', 'Tối ưu Fanpage', 'Hoàn thành', '₫1.200.000'],
  ['#VC-1046', 'Lê Hà', 'TikTok hỗ trợ', 'Chờ xử lý', '₫800.000'],
  ['#VC-1045', 'Phạm Nam', 'Thiết kế nội dung', 'Hoàn thành', '₫450.000']
];

export default function Home() {
  return (
    <main className="min-h-screen">
      <div className="mx-auto flex max-w-7xl gap-6 p-5 lg:p-8">
        <aside className="hidden w-60 shrink-0 lg:block">
          <div className="sticky top-6">
            <div className="mb-8 flex items-center gap-3">
              <div className="grid h-11 w-11 place-items-center rounded-2xl bg-indigo-500 font-black">V</div>
              <div><div className="font-bold">VCAM Pro</div><div className="text-xs text-gray-500">v1.0 MVP</div></div>
            </div>
            <nav className="space-y-2 text-sm">
              {['Tổng quan','Khách hàng','Tài khoản MXH','Đơn hàng','Yêu cầu hỗ trợ','Thống kê','Cài đặt'].map((x,i) =>
                <div key={x} className={`rounded-xl px-4 py-3 ${i===0?'bg-indigo-500/15 text-indigo-300':'text-gray-400 hover:bg-white/5'}`}>{x}</div>
              )}
            </nav>
          </div>
        </aside>

        <section className="min-w-0 flex-1">
          <header className="mb-7 flex items-center justify-between">
            <div><p className="text-sm text-gray-500">Xin chào 👋</p><h1 className="text-3xl font-bold">Tổng quan</h1></div>
            <button className="btn bg-indigo-500 hover:bg-indigo-400">+ Tạo đơn</button>
          </header>

          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map(([label,value,note]) => <div className="card" key={label}>
              <div className="text-sm text-gray-500">{label}</div>
              <div className="mt-2 text-2xl font-bold">{value}</div>
              <div className="mt-2 text-xs text-emerald-400">{note}</div>
            </div>)}
          </div>

          <div className="mt-6 grid gap-6 xl:grid-cols-[1.6fr_1fr]">
            <div className="card">
              <div className="mb-5 flex items-center justify-between">
                <div><h2 className="font-bold">Đơn hàng gần đây</h2><p className="text-xs text-gray-500">Dữ liệu demo</p></div>
                <span className="text-xs text-indigo-300">Xem tất cả →</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="text-xs text-gray-500"><tr><th className="pb-3">Mã</th><th>Khách hàng</th><th>Dịch vụ</th><th>Trạng thái</th><th>Giá</th></tr></thead>
                  <tbody>{orders.map(o => <tr key={o[0]} className="border-t border-white/5">
                    <td className="py-4 font-semibold">{o[0]}</td><td>{o[1]}</td><td>{o[2]}</td>
                    <td><span className="rounded-full bg-white/5 px-2.5 py-1 text-xs">{o[3]}</span></td><td>{o[4]}</td>
                  </tr>)}</tbody>
                </table>
              </div>
            </div>
            <div className="card">
              <h2 className="font-bold">Tác vụ nhanh</h2>
              <div className="mt-4 space-y-3">
                {['Thêm khách hàng','Thêm tài khoản MXH','Tạo yêu cầu hỗ trợ','Xuất báo cáo'].map(x =>
                  <button key={x} className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-left text-sm hover:bg-white/[0.07]">{x}<span className="float-right text-gray-500">→</span></button>
                )}
              </div>
            </div>
          </div>

          <div className="card mt-6">
            <h2 className="font-bold">Kiến trúc MVP</h2>
            <p className="mt-2 text-sm text-gray-400">Frontend Next.js/TypeScript + Tailwind. API mẫu nằm tại <code className="text-indigo-300">/api</code>; dữ liệu hiện là demo và có thể nối PostgreSQL ở bước tiếp theo.</p>
          </div>
        </section>
      </div>
    </main>
  );
}